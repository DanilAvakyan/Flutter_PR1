# Практическая работа №1
## Создание макетов на flutter
__Цель: В ходе данной практической работы необходимо сделать макет приложения во flutter. <br>
Ход работы:__
<br>
![Screenshot_2](https://user-images.githubusercontent.com/78299124/193340042-57dfe8dd-a6bc-4a4c-82de-791bad1a2875.png)
<br>
![Screenshot_3](https://user-images.githubusercontent.com/78299124/193340074-4332958f-7667-4734-8318-a0abafc2870d.png)
<br>
![Screenshot_4](https://user-images.githubusercontent.com/78299124/193340231-e38d5f44-fa62-48d4-8fe8-940ca6c90182.png)
<br>
![Screenshot_5](https://user-images.githubusercontent.com/78299124/193340247-e6897a12-64f7-4e5f-8e67-17fc6fce4da9.png)
<br>
__Вывод: В ходе данной практической работы было сделано два макета во flutter.__
