package com.example.verstka

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
